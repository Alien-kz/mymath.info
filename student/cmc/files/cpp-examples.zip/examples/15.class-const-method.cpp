#include <iostream>

using namespace std;

class Square
{
public:
	enum Color
	{
		RED,
		BLUE,
		WHITE,
		UNKNOWN
	};
private:
	double size;		//изменяемый параметр
	const int id;		//неизменяемый индивидуальный параметр
	const Color color;	//неизменяемый индивидуальный параметр

	static const int step = 1;	//неизменяемый общий параметр
	static int counter;

public:
	Square(double a = 1.0, Square::Color newColor = Square::UNKNOWN);
	friend ostream & operator<<(ostream & out, const Square & s);

	void printColor(ostream & out = cout) const;
	bool operator>(const Square & s) const;

	static void printCounter();
};

int Square::counter = 0;

Square::Square(double newSize, Square::Color newColor) : size(newSize), color(newColor), id(++counter) //блок инициализации констант (перечислять через запятую)
{
	if (size <= 0.0)
		size = 1.0;
}

void Square::printColor(ostream & out) const
{
	switch (color)
	{
		case RED: {out << "red"; break;}
		case Square::BLUE: {out << "blue"; break;}
		case Square::WHITE: {out << "white"; break;}
		default: {out << "unknown"; break;}
	}
//	size = 5; // error: assignment of member ‘Square::size’ in read-only object
}

bool Square::operator>(const Square & s) const //операторы + - * / % > < >= <= == [] () тоже const, если они не изменяют САМ объект
{
	return (size > s.size);
}

void Square::printCounter()
{
	cout << counter << endl;
}

ostream & operator<<(ostream & out, const Square & s)
{
	out << "Square #" << s.id;
	out << " (size = " << s.size << "; color = ";
	s.printColor();
	out << ")" << endl;
	return out;
}

int main()
{
	Square s1, s2(5.0), s3(5.0, Square::WHITE);
	s3.printColor();
	cout << endl;

	cout << s1 << s2 << s3;

	Square::printCounter();
	return 0;
}
