#include <QPainter>
#include <QColor>
#include <QDebug>

#include "game.h"

Game::Game() {
  size = QSize(600, 600);
  position = QVector2D(size.width() / 2, size.height() / 2);
  velocity = QVector2D(10.0, 20.0);
  gravity = QVector2D(0.0, 10.0);
  tau = 0.1;
  radius = 50.0;
  texture_ball = new QPixmap("pictures/ball.png");
}

void Game::step() {
  position = position + tau * velocity;
  velocity = velocity + tau * gravity;

  QVector2D normal[] = { QVector2D(1, 0),
                         QVector2D(0, -1),
                         QVector2D(-1, 0),
                         QVector2D(0, 1) };
  QVector2D border[] = { QVector2D(radius, radius),
                         QVector2D(radius, size.height() - radius),
                         QVector2D(size.width() - radius, size.height() - radius),
                         QVector2D(size.width() - radius, radius) };
  for (int i = 0; i < 4; i++) {
    qreal normal_factor = QVector2D::dotProduct(position - border[i], normal[i]);
    if (normal_factor < 0) {
      position = position - 2 * normal_factor * normal[i];
      velocity = velocity - 2 * QVector2D::dotProduct(velocity, normal[i]) * normal[i];
    }
  }

  qDebug() << position << velocity;
}

void Game::draw(QPixmap *pixmap) {
  pixmap->fill(Qt::white);
  QPainter painter(pixmap);
  painter.drawPixmap(position.x() - radius,
                     position.y() - radius,
                     *texture_ball);
}

Game::~Game() {
  delete texture_ball;
}
