1. Сбор датасета
python+telegram bot: [audio_digits_dataset]

```
mkdir dataset/ dataset/ogg/ dataset/wav/
python3 audio_digits_dataset_bot.py
```

2. Подготовка датасета
python:              [energy vad]
```
mkdir dataset/splitted
python3 split_by_vad.py dataset/wav/7_1_8_4_6.wav 0.1 0.07 dataset/splitted/
```
Интересный пример: dataset//wav/1_1_4_3_9.wav


3. Обучение модели
python+sklearn:      [classifier]
```
jupyter notebook ml.py
```

4. Продакшн
python+telegram bot: [audio_digits_recognition]
